import { hash, verify } from "argon2";
import jwt from "jsonwebtoken";
import { DatabaseService } from "../database-prisma/database.service"; // named import
import { User } from "@prisma/client";

const ACCESS_KEY = process.env.ACCESS_KEY!;
const REFRESH_KEY = process.env.REFRESH_KEY!;

const database = new DatabaseService(); // instantiate here

export const registerLocal = async (user: Pick<User, "email" | "password">) => {
  user.password = await hash(user.password);

  const existing = await database.user.findUnique({
    where: { email: user.email },
  });
  if (existing) throw new Error("Your email is already registered");

  const newUser = await database.user.create({ data: user });
  const tokens = await generateTokens({ id: newUser.id });

  await storeRefreshToken(newUser.id, tokens.refreshToken);
  return tokens;
};

export const loginLocal = async (user: Pick<User, "email" | "password">) => {
  const foundUser = await database.user.findUnique({
    where: { email: user.email },
  });
  if (!foundUser) throw new Error("User is not registered");

  const isValid = await verify(foundUser.password, user.password);
  if (!isValid) throw new Error("Incorrect password");

  const tokens = await generateTokens({ id: foundUser.id });
  await storeRefreshToken(foundUser.id, tokens.refreshToken);

  return {
    id: foundUser.id,
    accessToken: tokens.accessToken,
    refreshToken: tokens.refreshToken,
    role: foundUser.role,
  };
};

export const logout = async (user: { id: string }) => {
  const found = await database.user.findUnique({ where: { id: user.id } });
  if (!found) throw new Error("User is not registered");
  if (!found.refreshToken) throw new Error("Already logged out");

  await database.user.update({
    where: { id: user.id },
    data: { refreshToken: null },
  });
};

export const refreshToken = async (user: {
  id: string;
  refreshToken: string;
}) => {
  const found = await database.user.findUnique({ where: { id: user.id } });
  if (!found || !found.refreshToken) throw new Error("Invalid refresh token");

  const isValid = await verify(found.refreshToken, user.refreshToken);
  if (!isValid) throw new Error("Invalid refresh token");

  const tokens = await generateTokens({ id: found.id });
  await storeRefreshToken(found.id, tokens.refreshToken);

  return tokens;
};

const storeRefreshToken = async (id: string, refreshToken: string) => {
  const hashed = await hash(refreshToken);
  await database.user.update({ where: { id }, data: { refreshToken: hashed } });
};

const generateTokens = async (payload: { id: string }) => {
  const accessToken = jwt.sign(payload, ACCESS_KEY, { expiresIn: "7d" });
  const refreshToken = jwt.sign(payload, REFRESH_KEY, { expiresIn: "70d" });
  return { accessToken, refreshToken };
};
