import { PrismaClient } from "@prisma/client";

export class DatabaseService {
  private prisma: PrismaClient;

  constructor() {
    this.prisma = new PrismaClient();
  }

  // Expose Prisma client directly if needed
  get client() {
    return this.prisma;
  }

  // Add getters for your Prisma models to use like this.database.booking.findUnique(...)
  get user() {
    return this.prisma.user;
  }

  get hotel() {
    return this.prisma.hotel;
  }

  get room() {
    return this.prisma.room;
  }

  get booking() {
    return this.prisma.booking;
  }

  get payment() {
    return this.prisma.payment;
  }

  get hotelApiProvider() {
    return this.prisma.hotelApiProvider;
  }

  // Example custom helper methods:

  async findPaymentById(id: string) {
    return this.prisma.payment.findUnique({ where: { id } });
  }

  async createPayment(data: any) {
    return this.prisma.payment.create({ data });
  }

  // Add more helper methods as you need...

  // Disconnect Prisma client (e.g. on app shutdown)
  async disconnect() {
    await this.prisma.$disconnect();
  }
}
