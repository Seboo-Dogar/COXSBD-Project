import { Request, Response } from "express";
import * as authService from "../services/auth.service";

export const registerLocal = async (req: Request, res: Response) => {
  try {
    const tokens = await authService.registerLocal(req.body);
    res.status(201).json(tokens);
  } catch (err) {
    if (err instanceof Error) {
      res.status(403).json({ message: err.message });
    } else {
      res.status(403).json({ message: "Something went wrong" });
    }
  }
};

export const loginLocal = async (req: Request, res: Response) => {
  try {
    const tokens = await authService.loginLocal(req.body);
    res.status(200).json(tokens);
  } catch (err) {
    if (err instanceof Error) {
      res.status(403).json({ message: err.message });
    } else {
      res.status(403).json({ message: "Something went wrong" });
    }
  }
};

export const logout = async (req: Request, res: Response) => {
  try {
    if (!req.user) return res.status(401).json({ message: "Not authenticated" });

    await authService.logout({ id: req.user.id });
    res.status(200).json({ message: "Logged out" });
  } catch (err) {
    if (err instanceof Error) {
      res.status(403).json({ message: err.message });
    } else {
      res.status(403).json({ message: "Something went wrong" });
    }
  }
};

export const refreshToken = async (req: Request, res: Response) => {
  try {
    if (!req.user || !req.user.refreshToken) {
      return res.status(401).json({ message: "Missing refresh token" });
    }

    const tokens = await authService.refreshToken({
      id: req.user.id,
      refreshToken: req.user.refreshToken,
    });

    res.status(201).json(tokens);
  } catch (err) {
    if (err instanceof Error) {
      res.status(403).json({ message: err.message });
    } else {
      res.status(403).json({ message: "Something went wrong" });
    }
  }
};
