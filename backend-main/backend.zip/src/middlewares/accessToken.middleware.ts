import { Request, Response, NextFunction } from "express";
import jwt, { JwtPayload } from "jsonwebtoken";

const ACCESS_KEY = process.env.ACCESS_KEY!;
const REFRESH_KEY = process.env.REFRESH_KEY!;

interface JwtUserPayload extends JwtPayload {
  id: string;
}

export const accessTokenMiddleware = (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  const authHeader = req.headers.authorization;
  if (!authHeader) return res.status(401).json({ message: "Missing token" });

  const token = authHeader.split(" ")[1];

  try {
    const payload = jwt.verify(token, ACCESS_KEY) as JwtUserPayload;
    if (!payload.id) return res.status(403).json({ message: "Invalid token" });

    req.user = { id: payload.id };
    next();
  } catch {
    return res.status(403).json({ message: "Invalid token" });
  }
};

export const refreshTokenMiddleware = (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  const authHeader = req.headers.authorization;
  if (!authHeader)
    return res.status(401).json({ message: "Missing refresh token" });

  const token = authHeader.split(" ")[1];

  try {
    const payload = jwt.verify(token, REFRESH_KEY) as JwtUserPayload;
    if (!payload.id)
      return res.status(403).json({ message: "Invalid refresh token" });

    req.user = { id: payload.id, refreshToken: token };
    next();
  } catch {
    return res.status(403).json({ message: "Invalid refresh token" });
  }
};
