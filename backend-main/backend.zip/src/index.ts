import "reflect-metadata";
import express, { Request, Response, NextFunction } from "express";
import cors from "cors";
import dotenv from "dotenv";
import helmet from "helmet";
import swaggerUi from "swagger-ui-express";
import swaggerJsdoc from "swagger-jsdoc";
import hotelRoutes from "./routes/hotel.routes";
import authRoutes from "./routes/auth.routes";
import { PrismaClient } from "@prisma/client";
import { createServer } from "http";
import { Server, Socket } from "socket.io";
import messageRoutes from "./routes/message.routes";
import currencyRoutes from "./routes/currency.routes";

dotenv.config();

const app = express();
const PORT = process.env.PORT || 1337;

// Middlewares
app.use("/api/currency", currencyRoutes);
app.use(express.json());
app.use(helmet());
app.use(
  cors({
    origin: [
      "http://localhost:3000",
      "http://localhost:80",
      "http://localhost:8080",
      "http://coxsbd.com",
      "https://coxsbd.com",
    ],
    methods: "GET,HEAD,PUT,PATCH,POST,DELETE,OPTIONS",
    credentials: true,
  })
);

const prisma = new PrismaClient();

// Create HTTP + Socket.IO server
const httpServer = createServer(app);
const io = new Server(httpServer, {
  cors: {
    origin: "*", // TODO: Replace with frontend URL in production
    methods: ["GET", "POST"],
  },
});

// REST API to fetch messages
app.get("/messages", async (req: Request, res: Response) => {
  const messages = await prisma.message.findMany({
    orderBy: { createdAt: "asc" },
  });
  res.json(messages);
});

// Socket.IO for real-time messaging
io.on("connection", (socket: Socket) => {
  console.log("User connected:", socket.id);

  socket.on("sendMessage", async (data: { text: string; senderId: string; receiverId: string }) => {
  try {
    const message = await prisma.message.create({
      data: {
        text: data.text,
        senderId: data.senderId,
        receiverId: data.receiverId,
      },
      include: { sender: true, receiver: true }, // optional: populate user info
    });

    io.emit("receiveMessage", message);
  } catch (err) {
    console.error("Message save error:", err);
  }
});

  socket.on("disconnect", () => {
    console.log("User disconnected:", socket.id);
  });
});

// Swagger setup
const swaggerOptions = {
  definition: {
    openapi: "3.0.0",
    info: {
      title: "CoxsBD Backend API",
      version: "1.0",
      description: "API documentation for CoxsBD Backend",
    },
    components: {
      securitySchemes: {
        bearerAuth: { type: "http", scheme: "bearer" },
      },
    },
    security: [{ bearerAuth: [] }],
  },
  apis: ["./routes/*.ts"], // Adjust if needed
};

const swaggerSpecs = swaggerJsdoc(swaggerOptions);
app.use("/docs", swaggerUi.serve, swaggerUi.setup(swaggerSpecs));

// Routes
app.use("/auth", authRoutes);
app.use("/api/hotels", hotelRoutes);

app.get("/", (req: Request, res: Response) => {
  res.send("Server is running...");
});

app.use("/api/currencies", currencyRoutes);
app.use("/api/messages", messageRoutes);

// Centralized error handler
app.use((err: any, req: Request, res: Response, next: NextFunction) => {
  console.error(err.stack);
  res
    .status(err.status || 500)
    .json({ message: err.message || "Internal Server Error" });
});

// Start server with Socket.IO
httpServer.listen(PORT, () => {
  console.log(`Server listening on port ${PORT}`);
});
